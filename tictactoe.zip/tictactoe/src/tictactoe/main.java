package tictactoe;

import java.util.Scanner;

class test{
	
	public int hi(){
		return 100;
	}
}

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the size of the board EX. 4");
		Scanner input = new Scanner (System.in);
        int size = input.nextInt();
        int human =1;
        int comp =0;
         Drawboard board = new Drawboard();
          board.draw(size);
          String string ="";
          System.out.println("////////////");
          System.out.println("enter coordinate EX: 1,2");
            	   string =input.next();
              while(string!="quit"){
            	  if(string == "quit") break;
            	   System.out.println("\n");
            	   String parts[] = null;
            	   try {  
    			        parts= string.split(",");
    	                     
    	           
    			    } catch (ArrayIndexOutOfBoundsException e) {
    			     
    			       System.out.println(e);
    			    }
            	   int x =0;
            	   int y =0;
            	   try{
                       
         	            x = Integer.parseInt(parts[0]);
         	            y = Integer.parseInt(parts[1]);
         	       
         	            board.addCoord(x, y, 1);
                        board.drawBoard();
               
         	         }catch(NumberFormatException e){
         	        	   System.out.println(e);  System.out.println("enter coordinate o quit");
         	               string =input.nextLine();
          	               System.out.println("\n");
          	   
                          }
             
            	   System.out.println("enter coordinate example: 1,2");
            	   string =input.next();
              }
 
       	   System.out.println("ended");

	}

}
