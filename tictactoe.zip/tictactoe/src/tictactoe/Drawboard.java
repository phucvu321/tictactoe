package tictactoe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class coordinate{
	int player;
	private Integer x;
	private Integer y;
    private	char c;
	public coordinate(int x,int y,int player){
		this.x = x;
		this.y = y;
		if(player == 1)
		this.c = 'X';
		else this.c = 'O';
	}
	public Integer getX() {
		return x;
	}
 
	public Integer getY() {
		return y;
	}
 
	public char getChar() {
		return c;
	}
 
	
}
// sort coordinates form least to greatest ex: 1,2 ;1,4; 3,4; 4,4
 class FooComparator implements Comparator<coordinate> {
    public int compare(coordinate a, coordinate b) {
     Integer  Comparison = a.getX().compareTo(b.getX());
        return  Comparison == 0 ? a.getY().compareTo(b.getY()):Comparison;
     
    }
 }
public class Drawboard {
	private String horizontalDraw = "+ - ";
	private String verticalDraw = "| ";
	private List<coordinate> coorList= new ArrayList<coordinate>();
	private int size;
	 
	public Drawboard(){
		coordinate coor = new coordinate(-5,-5,1);
		coorList.add(coor);
	}
   public void draw(int size){
	   this.size = size;
	   int height =0;
	    while(height <size){
	    for(int i =0;i<size;i++){
	    	System.out.print(horizontalDraw);
	    	
	    }
	    System.out.print('+'+"\n");
	    for(int i =0;i<size;i++){
	    	System.out.print(verticalDraw +" "+" ");
	    	
	    }
	    System.out.print('|'+"\n");
	 
	    height ++;
     } //end of while
	    for(int i =0;i<size;i++){
	    	System.out.print(horizontalDraw);
	    	
	    }
		System.out.println('+');
   }//end of draw
   public void addCoord(int x, int y ,int player){
		coordinate coor = new coordinate(x,y,player);
   	     for(coordinate coorD:coorList){
   	    	 if(coorD.getX() == coor.getX()&&coorD.getY() == coor.getY()){ return;}
   	     }
		coorList.add(coor);
	    Collections.sort(coorList,new FooComparator() );
   }
    public void drawBoard(){
    
    	    
    	    	for(int height =0; height<this.size;height++){
    	    
    			    for(int i =0;i<size;i++){
    			    	System.out.print(horizontalDraw);
    			    	
    			    }
    			    System.out.print('+'+"\n");
    			    /////// 
    			    int counter =0;
    			   
    			    for(coordinate coorD:coorList) {
    		    		
    			    	if(coorD.getY()-1 == height) counter++;
    			    }
    			   
    			    if(counter ==0) 
    			    {
    			    	 for(int i =0;i<size;i++){
    			 	    	System.out.print(verticalDraw +" "+" ");
    			 	    	 
    			 	    }
    			 	  
    			    }
    			    else{
    					//System.out.print("vao day  ");
    			        int skip =0;
    			    	  int collumn =1;
    			    	int value =0;
    			    	for(coordinate coorD:coorList)  {
    			    		
    			    	     if(skip ==0){skip =1; continue;}
    			    	 
    			
    			    	 
    			    		if(coorD.getY()-1 == height){
    			    			 
    			    			 
    			    		          while(collumn <=this.size){
    			    			if(coorD.getX() == collumn){
    			    		
    			    			 
    			    				 System.out.print(verticalDraw + coorD.getChar()+" ");
    	    		    			   collumn ++;
    	    		    			   ++ value ;	
    	    		    			   
    	    		    	 
    	    		    			   if(value == counter) {
    			    			              
    			     
    			    			for(int i = collumn;i<=size;i++){
    			    				
    			    				System.out.print(verticalDraw +" "+" ");
    			    				
    			    			}break;
    			     
    			    			
    			    	        	}
    	    		    			   break;
    			    			}
    			    			
    			    			else {  
    			    				System.out.print(verticalDraw +" "+" ");
    			     			    collumn++;
    			    			}
    			    		}//new loop
    			    		}
    			    	 
    			    	}
    			    	
    			    	 
    			    }
    			  
    				///////
    			    System.out.print('|'+"\n");
    			 
    			   
    		     } //end of while
    			 
    			    for(int i =0;i<size;i++){
    			    	System.out.print(horizontalDraw);
    			    	
    			    }
    				System.out.println('+');
    	 
    	
    }
    public void print(){

    	     for(coordinate coor: coorList){
    		 System.out.println(coor.getX());
    		 System.out.println(coor.getY());
    	  
    		
    		 
    	 }
    }
   public int getSize(){
	   return size;
   }
}
